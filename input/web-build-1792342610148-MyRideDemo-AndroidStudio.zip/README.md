# MyRide Demo (Android Studio)

This is a small Java Android Studio demo project.

## What it does
- Shows a simulated ride request.
- Opens Android Accessibility Settings so the demo service can be enabled manually.
- Includes a demo-only accessibility service that observes accessibility events and logs a simulated label.
- It deliberately does not click or accept rides in Uber, Rapido, Ola, or other third-party apps.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Connect an Android phone or start an emulator.
4. Press Run.

To build an APK in Android Studio: **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.

## Notes
- Accessibility access is powerful. Enable it only when you understand and trust the service.
- The project requires Android Studio/Android SDK to compile; no prebuilt APK is included.
