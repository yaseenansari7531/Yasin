package com.example.myride_demo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status;
    private TextView demoRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(36, 48, 36, 36);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("MyRide Automation — Demo");
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        layout.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView note = new TextView(this);
        note.setText("\nSafe demo only: this app does not accept real rides in Uber, Rapido, or Ola.");
        note.setTextSize(16);
        layout.addView(note);

        status = new TextView(this);
        status.setText("\nAccessibility service: check Android Settings");
        status.setTextSize(16);
        layout.addView(status);

        Button settings = new Button(this);
        settings.setText("Open Accessibility Settings");
        settings.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        layout.addView(settings, new LinearLayout.LayoutParams(-1, -2));

        demoRequest = new TextView(this);
        demoRequest.setText("\nSIMULATED RIDE REQUEST\nPickup: Demo Market\nDrop: Demo Station\nFare: ₹100");
        demoRequest.setTextSize(18);
        demoRequest.setPadding(20, 24, 20, 24);
        demoRequest.setBackgroundColor(0xFFEFEFEF);
        layout.addView(demoRequest, new LinearLayout.LayoutParams(-1, -2));

        Button simulate = new Button(this);
        simulate.setText("Show simulated ACCEPT button");
        simulate.setOnClickListener(v -> {
            demoRequest.setText("SIMULATED RIDE REQUEST\nPickup: Demo Market\nDrop: Demo Station\nFare: ₹100\n\nACCEPT (demo only)");
            status.setText("Demo request shown. No real ride was accepted.");
        });
        layout.addView(simulate, new LinearLayout.LayoutParams(-1, -2));

        Button reset = new Button(this);
        reset.setText("Reset demo");
        reset.setOnClickListener(v -> {
            demoRequest.setText("SIMULATED RIDE REQUEST\nPickup: Demo Market\nDrop: Demo Station\nFare: ₹100");
            status.setText("Demo reset. No action taken.");
        });
        layout.addView(reset, new LinearLayout.LayoutParams(-1, -2));

        setContentView(layout);
    }
}
