package com.example.myride_demo;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

/**
 * Demo-only AccessibilityService.
 * Intentionally does NOT click controls in third-party ride-hailing apps.
 * It only observes accessibility events and logs simulated demo text.
 */
public class MyRideAutomationService extends AccessibilityService {
    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;

        int type = event.getEventType();
        if (type != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                && type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            return;
        }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        try {
            inspectDemoTree(root);
        } finally {
            root.recycle();
        }
    }

    private void inspectDemoTree(AccessibilityNodeInfo node) {
        if (node == null) return;

        CharSequence text = node.getText();
        if (text != null) {
            String label = text.toString().trim();
            if ("ACCEPT (demo only)".equalsIgnoreCase(label)) {
                android.util.Log.d("MyRideDemo", "Simulated ACCEPT label detected; no click performed.");
            }
        }

        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                inspectDemoTree(child);
                child.recycle();
            }
        }
    }

    @Override
    public void onInterrupt() {
        android.util.Log.d("MyRideDemo", "Accessibility service interrupted.");
    }
}
