# MyRide Clean Demo (no Accessibility Service)

This is a minimal Android Studio project for a local simulated ride-request screen.

## Safety and permissions
- No Accessibility Service is included.
- No `BIND_ACCESSIBILITY_SERVICE` permission/service is declared.
- No internet, location, SMS, contacts, or phone permissions are requested.
- The ACCEPT button changes only the status text inside this demo app. It cannot read or click other apps and does not accept real rides.

## Build
Open the folder in Android Studio and build the debug APK, or use a trusted Android build environment. The expected output is `app/build/outputs/apk/debug/app-debug.apk`.

The project ZIP is source code, not an APK. Play Protect may still warn about sideloaded/unverified apps; removing Accessibility Service does not guarantee that all warnings disappear.
