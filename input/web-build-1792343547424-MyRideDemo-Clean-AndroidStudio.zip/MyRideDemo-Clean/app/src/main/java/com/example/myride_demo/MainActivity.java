package com.example.myride_demo;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(28, 36, 28, 28);

        TextView title = new TextView(this);
        title.setText("MyRide Clean Demo");
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView note = new TextView(this);
        note.setText("SAFE TEST SCREEN\n\nThis app only simulates a ride request. It does not read other apps, use Accessibility Service, or accept real rides.");
        note.setTextSize(17);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams noteParams = new LinearLayout.LayoutParams(-1, -2);
        noteParams.topMargin = 28;
        root.addView(note, noteParams);

        TextView request = new TextView(this);
        request.setText("DEMO REQUEST\nPickup: Test Location\nDrop: Demo Destination\nFare: ₹100 (sample only)");
        request.setTextSize(18);
        request.setGravity(Gravity.CENTER);
        request.setPadding(12, 24, 12, 24);
        LinearLayout.LayoutParams requestParams = new LinearLayout.LayoutParams(-1, -2);
        requestParams.topMargin = 28;
        root.addView(request, requestParams);

        Button accept = new Button(this);
        accept.setText("ACCEPT (DEMO ONLY)");
        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(-1, -2);
        buttonParams.topMargin = 20;
        root.addView(accept, buttonParams);

        status = new TextView(this);
        status.setText("Status: Waiting for demo tap");
        status.setTextSize(16);
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(-1, -2);
        statusParams.topMargin = 20;
        root.addView(status, statusParams);

        accept.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                status.setText("Demo accepted locally. No real ride was accepted.");
            }
        });

        setContentView(root);
    }
}
